from .otBase import BaseTTXConverter


class table_V_A_R_C_(BaseTTXConverter):
    pass
